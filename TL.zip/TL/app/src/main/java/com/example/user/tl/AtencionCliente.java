package com.example.user.tl;

import android.content.Intent;
import android.net.Uri;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;import android.support.v4.app.ActivityCompat;import android.Manifest;import android.content.pm.PackageManager;

import com.google.android.gms.ads.AdView;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.MobileAds;

public class AtencionCliente extends AppCompatActivity {
    Button Enviar, fab;
    private AdView mAdView;
    private Button mBack;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_atencion_cliente);

        MobileAds.initialize(this,
                "ca-app-pub-4057425766657641~8024342091");

        mAdView = findViewById(R.id.adView);
        AdRequest adRequest = new AdRequest.Builder().build();
        mAdView.loadAd(adRequest);
        mBack=(Button) findViewById(R.id.retroceder);
        Enviar = (Button)findViewById(R.id.btnEnviar);
        if(ActivityCompat.checkSelfPermission(
                AtencionCliente.this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED&& ActivityCompat.checkSelfPermission(
                AtencionCliente.this,Manifest
                        .permission.SEND_SMS)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(AtencionCliente.this,new String[]
                    { Manifest.permission.SEND_SMS,},1000);
        }else{
        };

        if(ActivityCompat.checkSelfPermission(
                AtencionCliente.this, Manifest.permission.CALL_PHONE)
                != PackageManager.PERMISSION_GRANTED&& ActivityCompat.checkSelfPermission(
                AtencionCliente.this,Manifest
                        .permission.CALL_PHONE)!= PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(AtencionCliente.this,new String[]
                    { Manifest.permission.CALL_PHONE,},1000);
        }else{
        };
        Enviar.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                enviarMensaje("979345148","HOLA, TENGO UNA CONSULTA SOBRE LA APLICACION; " +
                        "RESPONDEME EN CUANTO PUEDAS");
            }
        });
        fab = (Button)findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(Intent.ACTION_CALL, Uri.parse("tel:920121210"));
                if(ActivityCompat.checkSelfPermission(AtencionCliente.this, Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED)
                    return;
                startActivity(i);
            }
        });
        mBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AtencionCliente.this, MainActivity.class);
                startActivity(intent);
                finish();
                return;
            }
        });

    }
    private void enviarMensaje (String numero, String mensaje){
        try {
            SmsManager sms = SmsManager.getDefault();
            sms.sendTextMessage(numero,null,mensaje,null,null);
            Toast.makeText(getApplicationContext(), "Mensaje Enviado.", Toast.LENGTH_LONG).show();
        }
        catch (Exception e) {
            Toast.makeText(getApplicationContext(), "Mensaje no enviado, datos incorrectos.", Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
}
